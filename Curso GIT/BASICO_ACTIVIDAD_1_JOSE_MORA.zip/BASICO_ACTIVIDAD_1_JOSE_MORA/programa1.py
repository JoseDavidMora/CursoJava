# Programa 1. Genera una lista del 1 al 100 en la consola.
# Commit 1: Primer commit. Generacion del proyecto
# Commit 2: Se añade la funcionalidad de preguntarle al usuario el rango de la lista
# Commit 3: Se añade la opcion de imprimir el resultado en un archivo de texto
# Cambio en el staging area: Se añade la opcion de que el usuario elija el nombre del archivo
# Cambio en el working area: Se corrige el defecto que cuando a > b no imprime la lista y que imprime en el archivo si la s es miniscula

# Funcion que genera la lista
def lista(num_a,num_b,imprime,archivo):
    if(num_a > num_b):
        incremento = -1
    else:
        incremento = 1
    for i in range(num_a,num_b + incremento,incremento):
        imprime(i,archivo)

def imprime_consola(cadena,archivo):
    print(cadena)

def imprime_archivo(cadena,archivo):
    archivo.write("%s\n" % cadena)

a = int(input("Ingrese el numero con el que desea empezar: "))

b = int(input("Ingrese el numero con el que desea terminar: "))

eleccion = input("Desea que la lista se imprima en un archivo? (S/N): ")

if (eleccion.upper() == 'S'):
    nombre = input("Ingrese el nombre del archivo, si no elige uno sea default: ")
    if(nombre == ''):
        nombre = 'default'
    nombre += '.txt'
    fp = open(nombre,"w")
    imp = imprime_archivo
else:
    fp = None
    imp = imprime_consola


# Llamado a la funcion de la lista
lista(a,b,imp,fp)

# Se espera un enter para continuar
input("Presione enter para continuar.") 
