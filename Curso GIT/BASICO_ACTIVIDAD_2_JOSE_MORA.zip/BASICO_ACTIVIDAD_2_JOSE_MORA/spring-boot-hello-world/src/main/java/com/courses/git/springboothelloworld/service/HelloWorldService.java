package com.courses.git.springboothelloworld.service;

public abstract interface HelloWorldService {

  /**
   * 
   * @return
   */
  public abstract String sayHello();

}
